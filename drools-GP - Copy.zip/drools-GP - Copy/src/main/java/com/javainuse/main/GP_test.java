package com.javainuse.main;

import org.kie.api.runtime.KieSession;

import java.util.Scanner;

import org.kie.api.KieServices;
import org.kie.api.runtime.KieContainer;


import com.javainuse.model.Player;
 


public class GP_test {
    public static void main(String[] args) {
        KieServices ks = KieServices.Factory.get();
        KieContainer kContainer = ks.getKieClasspathContainer();
        KieSession kSession = kContainer.newKieSession("ksession-rules");

        Scanner scanner = new Scanner(System.in);

        // Get player details from user input
        System.out.print("Enter player's name: ");
        String name = scanner.nextLine();

        System.out.print("Enter player's birth date (YYYY-MM-DD): ");
        String birthDate = scanner.nextLine();

        System.out.print("Enter player's school type: ");
        String schoolType = scanner.nextLine();

        System.out.print("Enter player's gender: ");
        String gender = scanner.nextLine();

        System.out.print("Enter player's height (cm): ");
        int height = scanner.nextInt();

        System.out.print("Enter player's weight (kg): ");
        int weight = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter player's preferred sports (comma-separated): ");
        String[] preferredSports = scanner.nextLine().split(",");

        System.out.print("Enter parent's or sibling's sports history (comma-separated): ");
        String[] parentSportsHistory = scanner.nextLine().split(",");

        System.out.print("Enter player's test scores (comma-separated): ");
        String[] testScoresStr = scanner.nextLine().split(",");
        double[] testScores = new double[testScoresStr.length];
        for (int i = 0; i < testScoresStr.length; i++) {
            testScores[i] = Double.parseDouble(testScoresStr[i]);
        }

        System.out.print("Does the player have doctor approval? (true/false): ");
        boolean hasDoctorApproval = scanner.nextBoolean();

        System.out.print("Is the player's blood test normal? (true/false): ");
        boolean hasNormalBloodTest = scanner.nextBoolean();

        // Create player object
        Player player = new Player(name, birthDate, schoolType, gender, height, weight, 
                                  preferredSports, parentSportsHistory, testScores,
                                  hasDoctorApproval, hasNormalBloodTest);

        // Insert player into Drools session
        kSession.insert(player);
        kSession.fireAllRules();
        kSession.dispose();

        // Output the best category for the player
        System.out.println("The best category for " + player.getName() + " is: " + player.getBestCategory());
    }
}