package com.example.drools.controller;

import com.example.drools.model.Player;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/player")
public class PlayerController {

    private final KieSession kieSession;

    @Autowired
    public PlayerController(KieSession kieSession) {
        this.kieSession = kieSession;
        System.out.println("🔹 Drools KieSession initialized.");
    }

    @PostMapping("/categorize")
    public Map<String, Object> categorizePlayer(@RequestBody Player player) {
    	System.out.println("🔹 Request received for player: " + player.getName());

    	 
        System.out.println("  Medically Cleared: " + player.isMedicallyCleared());

    	
        Map<String, Object> response = new HashMap<>();
        response.put("name", player.getName());

        // Validate test scores
        if (player.getTestScores() == null || player.getTestScores().size() < 8) {
            response.put("errors", "Invalid or missing test scores. The player must have exactly 8 test scores.");
            return response;
        }synchronized (kieSession) {
            kieSession.insert(player);
            kieSession.fireAllRules();
        }
        
        // Ensure the best category and scores are not null
        String bestCategory = (player.getBestCategory() != null) ? player.getBestCategory() : "Unknown";
        Map<String, Double> categoryScores = (player.getCategoryScores() != null) ? player.getCategoryScores() : new HashMap<>();
        Map<String, Double> categoryPercentages = (player.getCategoryPercentages() != null) ? player.getCategoryPercentages() : new HashMap<>();
        List<String> errors = player.getErrors();
     // Format scores as percentages
        Map<String, String> formattedScores = new LinkedHashMap<>();
        for (Map.Entry<String, Double> entry : categoryScores.entrySet()) {
            formattedScores.put(entry.getKey(), String.format("%.2f%%", entry.getValue()));
        }
        
        Map<String, String> formattedPercentages = new LinkedHashMap<>();
        for (Map.Entry<String, Double> entry : categoryPercentages.entrySet()) {
            formattedPercentages.put(entry.getKey(), String.format("%.2f%%", entry.getValue()));
        }

        // Prepare response
        
        response.put("name", player.getName());
        response.put("bestCategory", bestCategory);
        response.put("categoryScores", categoryScores);
        response.put("categoryPercentages", formattedPercentages);
        
        if (!errors.isEmpty()) {
            response.put("errors", errors);
        }

        return response;
    }
}
