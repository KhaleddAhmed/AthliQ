package com.example.drools.controller;

import com.example.drools.model.Player;
import org.kie.api.runtime.KieSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

@RestController
@RequestMapping("/player")
public class PlayerController {

    private final KieSession kieSession;

    @Autowired
    public PlayerController(KieSession kieSession) {
        this.kieSession = kieSession;
        System.out.println("🔹 Drools KieSession initialized.");
    }

    @PostMapping("/categorize")
    public Map<String, Object> categorizePlayer(@RequestBody Player player) {
    	System.out.println("🔹 Request received for player: " + player.getName());

    	 
        System.out.println("  Medically Cleared: " + player.isMedicallyCleared());

    	
        Map<String, Object> response = new HashMap<>();
        response.put("name", player.getName());

        // Validate test scores
        if (player.getTestScores() == null || player.getTestScores().size() < 8) {
            response.put("errors", "Invalid or missing test scores. The player must have exactly 8 test scores.");
            return response;
        }synchronized (kieSession) {
            kieSession.insert(player);
            kieSession.fireAllRules();
        }
        
        // Ensure the best category and scores are not null
        String bestCategory = (player.getBestCategory() != null) ? player.getBestCategory() : "Unknown";
        Map<String, Double> categoryScores = (player.getCategoryScores() != null) ? player.getCategoryScores() : new HashMap<>();
        Map<String, Double> categoryPercentages = (player.getCategoryPercentages() != null) ? player.getCategoryPercentages() : new HashMap<>();
        List<String> errors = player.getErrors();
     // Format scores as percentages
        Map<String, String> formattedScores = new LinkedHashMap<>();
        for (Map.Entry<String, Double> entry : categoryScores.entrySet()) {
            formattedScores.put(entry.getKey(), String.format("%.2f%%", entry.getValue()));
        }
        
        Map<String, String> formattedPercentages = new LinkedHashMap<>();
        for (Map.Entry<String, Double> entry : categoryPercentages.entrySet()) {
            formattedPercentages.put(entry.getKey(), String.format("%.2f%%", entry.getValue()));
        }

        // Prepare response
        
        response.put("name", player.getName());
        response.put("bestCategory", bestCategory);
        response.put("categoryScores", categoryScores);
        response.put("categoryPercentages", formattedPercentages);
        
        if (!errors.isEmpty()) {
            response.put("errors", errors);
        }

        return response;
    }
    
//    @PostMapping(value = "/getGrade", produces = "application/json")
//    public Map<String, Object> gradePlayer(@RequestBody Player player) {
//        Map<String, Object> response = new LinkedHashMap<>();
//        response.put("name", player.getName());
//
//        List<Double> testScores = player.getTestScores();
//        if (testScores == null || testScores.size() != 8) {
//            response.put("error", "Player must have exactly 8 test scores.");
//            return response;
//        }
//
//        
//        Map<String, Double> testGrades = new LinkedHashMap<>();
//        List<String> testNames = Arrays.asList(
//        	    "Standing Long Jump (cm)",
//        	    "Trunk Flexibility from Long Sitting (cm)",
//        	    "Static Balance – Standing on One Leg (score)",
//        	    "Sit-ups in 30 Seconds (count)",
//        	    "Medicine Ball Push from Standing (cm)",
//        	    "Dynamic Balance (score)",
//        	    "30m Sprint (seconds)",
//        	    "Zigzag Running (seconds)"
//        	);
//        
//        for (int i = 0; i < testScores.size(); i++) {
//            String testName = testNames.get(i);
//            double grade = player.scoreTest(i);   
//            testGrades.put(testName, grade);
//        }
//
//        // Put the test grades 
//        response.put("testScores", testGrades);
//        return response;
//    }
    @PostMapping("/tests")
    public ResponseEntity<List<Player.TestResult>> getPlayerTestResults(@RequestBody Player player) {
        List<Double> testScores = player.getTestScores();

        String[] testNamesEn = {
            "Standing Long Jump Test (in cm) ", "Sit-and-Reach Flexibility (in cm)", "One-Leg Stand (30 seconds)", "Sit-up Test (30 seconds)",
            "Medicine Ball Push (1 kg) from Standing Position", "Straight-Line Walking (3 meters)", "30-Meter Sprint (in seconds)", "15-Meter Zigzag Run (in seconds)"
        };
        String[] testNamesAr = {
            " الوثب الطويل من الثبات (سم)", "(سم) مرونة الجذع من الجلوس الطويل", "الوقوف على قدم واحدة لمدة 30 ثانية بالدرجة", "الجلوس من الرقود 30 ثانية بالعدد",
            "دفع كرة طبية وزن 1 كجم من الثبات", "المشي على  خط مستقيم 3 امتار", "عدو 30 متر بالثانية", "الجري الزجزاجي 15 متر بالثانية"
        };

        Map<Integer, TreeMap<Integer, Double>> gradingScales = Map.of(
            0, Player.getGradingScaleTest1(),
            1, Player.getGradingScaleTest2(),
            2, Player.getGradingScaleTest3(),
            3, Player.getGradingScaleTest4(),
            4, Player.getGradingScaleTest5(),
            5, Player.getGradingScaleTest6(),
            6, Player.getGradingScaleTest7(),
            7, Player.getGradingScaleTest8()
        );

        List<Player.TestResult> results = new ArrayList<>();

        for (int i = 0; i < testScores.size(); i++) {
            double value = testScores.get(i);
            TreeMap<Integer, Double> scale = gradingScales.get(i);
            String grade = Player.determineGradeLevel(value, scale);

            Player.TestResult result = new Player.TestResult();
            result.setTestNameEn(testNamesEn[i]);
            result.setTestNameAr(testNamesAr[i]);
            result.setTestValue(value);
            result.setGradeLevel(grade);

            results.add(result);
        }

        return ResponseEntity.ok(results);
    }



}
