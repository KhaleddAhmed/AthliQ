package com.example.drools.model;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.*;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.fasterxml.jackson.annotation.JsonFormat;
import java.time.LocalDate;
import java.time.Period;

@Data
public class Player {
	private String name;
	
	@JsonFormat(pattern = "yyyy-MM-dd")  // Ensures JSON is converted to LocalDate
    private LocalDate birthDate;    
	private String schoolType;
	
	
	@JsonProperty("gender") 
    private String gender;
    
	
	private double height;
    private double weight;
    private List<String> preferredSports;
    private List<String> parentSportsHistory;
    private List<Double> testScores;
    
    @JsonProperty("hasDoctorApproval")
    private boolean hasDoctorApproval;
    
    
    @JsonProperty("hasNormalBloodTest")
    private boolean hasNormalBloodTest;
    
    private String bestCategory;
    private Map<String, Double> categoryScores = new HashMap<>(); // Category -> Score
    private Map<String, Double> categoryPercentages = new HashMap<>(); // Category -> Percentage
    private static final TreeMap<Integer, Double> gradingScaleTest1 = new TreeMap<>();
    private static final TreeMap<Integer, Double> gradingScaleTest2 = new TreeMap<>();
    private static final TreeMap<Integer, Double> gradingScaleTest3 = new TreeMap<>();
    private static final TreeMap<Integer, Double> gradingScaleTest4 = new TreeMap<>();
    private static final TreeMap<Integer, Double> gradingScaleTest5 = new TreeMap<>();
    private static final TreeMap<Integer, Double> gradingScaleTest6 = new TreeMap<>();
    private static final TreeMap<Integer, Double> gradingScaleTest7 = new TreeMap<>();
    private static final TreeMap<Integer, Double> gradingScaleTest8 = new TreeMap<>();
    
    static {
        // Initialize grading scales for each test
        // test1 :  (سم)الوثب الطويل من الثبات
    	gradingScaleTest1.put(1, 65.0);
        gradingScaleTest1.put(5, 75.0);
        //gradingScaleTest1.put(10, 80.0);
        gradingScaleTest1.put(15, 80.0);
        gradingScaleTest1.put(20, 85.0);
        gradingScaleTest1.put(25, 90.0);
        gradingScaleTest1.put(30, 90.0);
        gradingScaleTest1.put(40, 95.0);
        gradingScaleTest1.put(50, 100.0);
        gradingScaleTest1.put(60, 105.0);
        //gradingScaleTest1.put(70, 110.0);
        gradingScaleTest1.put(75, 110.0); 
        gradingScaleTest1.put(80, 115.0);
        gradingScaleTest1.put(90, 120.0);
        gradingScaleTest1.put(95, 130.0);
        gradingScaleTest1.put(99, 140.0);

        
        // مرونة الجذع من الجلوس الطويل (سم)
        gradingScaleTest2.put(1, 0.0);
        //gradingScaleTest2.put(5, 2.0);
        gradingScaleTest2.put(10, 2.0);
        //gradingScaleTest2.put(15, 3.0);
        gradingScaleTest2.put(20, 3.0);
        gradingScaleTest2.put(25, 4.0);
        //gradingScaleTest2.put(30, 5.0);
        gradingScaleTest2.put(40, 5.0);
        gradingScaleTest2.put(50, 6.0);
        gradingScaleTest2.put(60, 7.0);
       // gradingScaleTest2.put(70, 10.0);
        gradingScaleTest2.put(75, 10.0);
        gradingScaleTest2.put(80, 10.0);
        //gradingScaleTest2.put(90, 15.0);
        gradingScaleTest2.put(95, 15.0);
        gradingScaleTest2.put(99, 18.0);

       // التوازن الثابت الوقوف على قدم واحدة بالدرجة
        gradingScaleTest3.put(1, 2.49);
        gradingScaleTest3.put(5, 4.0);
        gradingScaleTest3.put(10, 5.0);
//        gradingScaleTest3.put(15, 6.0);
//        gradingScaleTest3.put(20, 6.0);
       gradingScaleTest3.put(25, 6.0);
        gradingScaleTest3.put(30, 6.0);
        //gradingScaleTest3.put(40, 7.0);
        gradingScaleTest3.put(50, 7.0);
        gradingScaleTest3.put(60, 7.0);
        gradingScaleTest3.put(70, 8.0);
        gradingScaleTest3.put(75, 8.315);
        gradingScaleTest3.put(80, 9.0);
        //gradingScaleTest3.put(90, 10.0);
        //gradingScaleTest3.put(95, 10.0);
        gradingScaleTest3.put(99, 10.0);

        //الجلوس من الرقود فى 30 ثانية بالمرة 
        gradingScaleTest4.put(1, 5.48);
        gradingScaleTest4.put(5, 9.0);
        gradingScaleTest4.put(10, 10.0);
        gradingScaleTest4.put(15, 10.2);
        gradingScaleTest4.put(20, 11.0);
        gradingScaleTest4.put(25, 12.0);
        gradingScaleTest4.put(30, 12.0);
        //gradingScaleTest4.put(40, 14.0);
        gradingScaleTest4.put(50, 14.0);
        gradingScaleTest4.put(60, 15.0);
        //gradingScaleTest4.put(70, 16.0);
        gradingScaleTest4.put(75, 16.0);
        gradingScaleTest4.put(80, 17.0);
        gradingScaleTest4.put(90, 18.0);
        gradingScaleTest4.put(95, 20.0);
        gradingScaleTest4.put(99, 22.0);

        // دفع كرة طبية من الثبات (سم)
        gradingScaleTest5.put(1, 125.0);
        gradingScaleTest5.put(5, 160.0);
        gradingScaleTest5.put(10, 170.0);
        gradingScaleTest5.put(15, 180.0);
        //gradingScaleTest5.put(20, 190.0);
        gradingScaleTest5.put(25, 190.0);
        gradingScaleTest5.put(30, 200.0);
        gradingScaleTest5.put(40, 210.0);
        gradingScaleTest5.put(50, 220.0);
        gradingScaleTest5.put(60, 230.0);
        gradingScaleTest5.put(70, 240.0);
        gradingScaleTest5.put(75, 250.0);
        gradingScaleTest5.put(80, 250.0);
        gradingScaleTest5.put(90, 270.0);
        gradingScaleTest5.put(95, 290.0);
        gradingScaleTest5.put(99, 335.0);

        //توازن ديناميكي بالدرجة 
        gradingScaleTest6.put(1, 3.0);
        //gradingScaleTest6.put(5, 4.0);
        gradingScaleTest6.put(10, 4.0);
       // gradingScaleTest6.put(15, 5.0);
        //gradingScaleTest6.put(20, 5.0);
        gradingScaleTest6.put(25, 5.0);
       // gradingScaleTest6.put(30, 6.0);
       // gradingScaleTest6.put(40, 6.0);
        gradingScaleTest6.put(50, 6.0);
        //gradingScaleTest6.put(60, 7.0);
        //gradingScaleTest6.put(70, 7.0);
        gradingScaleTest6.put(75, 7.0);
       // gradingScaleTest6.put(80, 8.0);
        //gradingScaleTest6.put(90, 8.0);
        gradingScaleTest6.put(95, 8.0);
        gradingScaleTest6.put(99, 9.0);

        //عدو 30 متر بالثانية
        gradingScaleTest7.put(1, 10.925);
        gradingScaleTest7.put(5, 9.36);
        gradingScaleTest7.put(10, 8.85);
        gradingScaleTest7.put(15, 8.43);
        gradingScaleTest7.put(20, 8.275);
        gradingScaleTest7.put(25, 8.15);
        gradingScaleTest7.put(30, 7.89);
        gradingScaleTest7.put(40, 7.68);
        gradingScaleTest7.put(50, 7.4);
        gradingScaleTest7.put(60, 7.14);
        gradingScaleTest7.put(70, 7.0);
        gradingScaleTest7.put(75, 6.75);
        gradingScaleTest7.put(80, 6.445);
        gradingScaleTest7.put(90, 6.23);
        gradingScaleTest7.put(95, 6.0);
        gradingScaleTest7.put(99, 5.485);

        //جري زجاجي الثانية
        gradingScaleTest8.put(1, 9.615);
        gradingScaleTest8.put(5, 9.056);
        gradingScaleTest8.put(10, 8.822);
        gradingScaleTest8.put(15, 8.372);
        gradingScaleTest8.put(20, 8.258);
        gradingScaleTest8.put(25, 8.116);
        gradingScaleTest8.put(30, 7.774);
        gradingScaleTest8.put(40, 7.44);
        gradingScaleTest8.put(50, 7.21);
        gradingScaleTest8.put(60, 6.974);
        gradingScaleTest8.put(70, 6.813);
        gradingScaleTest8.put(75, 6.638);
        gradingScaleTest8.put(80, 6.464);
        gradingScaleTest8.put(90, 6.22);
        gradingScaleTest8.put(95, 5.965);
        gradingScaleTest8.put(99, 5.133);
    }
    public Player() {
        // Default constructor required by Jackson
    }
    public Player(String name2, LocalDate birthDate2, String schoolType2, String gender2, double height2, double weight2,
              List<String> preferredSports2, List<String> parentSportsHistory2, List<Double> testScores2,
              boolean hasDoctorApproval2, boolean hasNormalBloodTest2) {
    this.name = name2;
    this.birthDate = birthDate2;
    this.schoolType = schoolType2;
    this.gender = gender2;
    this.height = height2;
    this.weight = weight2;
    this.preferredSports = preferredSports2;
    this.parentSportsHistory = parentSportsHistory2;
    this.testScores = (testScores2 != null) ? testScores2 : new ArrayList<>();
    this.hasDoctorApproval = false;
    this.hasNormalBloodTest = false;
}
    

//    private int interpolate(double score, Map<Integer, Double> gradingScale) {
//        // Reverse the map for score-to-grade lookup
//        Map<Double, Integer> scoreToGrade = new TreeMap<>();
//        for (Map.Entry<Integer, Double> entry : gradingScale.entrySet()) {
//            scoreToGrade.put(entry.getValue(), entry.getKey());
//        }
//
//        //System.out.println("Score-to-Grade Mapping: " + scoreToGrade);  // Debugging
//
//        // Handle out-of-range cases
//        double minScore = scoreToGrade.keySet().stream().min(Double::compareTo).orElseThrow();
//        double maxScore = scoreToGrade.keySet().stream().max(Double::compareTo).orElseThrow();
//
//        if (score < minScore) {
//            System.err.println("Warning: Score " + score + " is below the grading scale range. Returning min grade.");
//            return scoreToGrade.get(minScore);
//        }
//        if (score > maxScore) {
//            System.err.println("Warning: Score " + score + " exceeds the grading scale range. Returning max grade.");
//            return scoreToGrade.get(maxScore);
//        }
//
//        // Find closest lower and upper scores
//        double lowerScore = scoreToGrade.keySet().stream().filter(s -> s <= score).max(Double::compareTo).orElseThrow();
//        double upperScore = scoreToGrade.keySet().stream().filter(s -> s >= score).min(Double::compareTo).orElseThrow();
//
//        if (lowerScore == upperScore) {
//            return scoreToGrade.get(lowerScore);
//        }
//
//        int lowerGrade = scoreToGrade.get(lowerScore);
//        int upperGrade = scoreToGrade.get(upperScore);
//
//        return lowerGrade + (int) ((score - lowerScore) * (upperGrade - lowerGrade) / (upperScore - lowerScore));
//    }
    private int interpolate(double score, Map<Integer, Double> gradingScale) {
        // Reverse the map for score-to-grade lookup
        Map<Double, Integer> scoreToGrade = new TreeMap<>();
        for (Map.Entry<Integer, Double> entry : gradingScale.entrySet()) {
            scoreToGrade.put(entry.getValue(), entry.getKey());
        }

        // Handle out-of-range cases
//        double minScore = scoreToGrade.keySet().stream().min(Double::compareTo).orElseThrow();
//        double maxScore = scoreToGrade.keySet().stream().max(Double::compareTo).orElseThrow();

//        if (score < minScore) {
//            System.err.println("Warning: Score " + score + " is below the grading scale range. Returning min grade.");
//            return scoreToGrade.get(minScore);
//        }
//        if (score > maxScore) {
//            System.err.println("Warning: Score " + score + " exceeds the grading scale range. Returning max grade.");
//            return scoreToGrade.get(maxScore);
//        }

        // Find the smallest score that is greater than or equal to the given score
        double upperScore = scoreToGrade.keySet().stream()
                .filter(s -> s >= score)
                .min(Double::compareTo)
                .orElseThrow(); // Ensures it finds a valid score

        // Return the corresponding higher grade
        return scoreToGrade.get(upperScore);
    }




    
    public double scoreTest(int testIndex) {
        Map<Integer, Double> gradingScale;
        switch (testIndex) {
            case 0: gradingScale = gradingScaleTest1; break;
            case 1: gradingScale = gradingScaleTest2; break;
            case 2: gradingScale = gradingScaleTest3; break;
            case 3: gradingScale = gradingScaleTest4; break;
            case 4: gradingScale = gradingScaleTest5; break;
            case 5: gradingScale = gradingScaleTest6; break;
            case 6: gradingScale = gradingScaleTest7; break;
            case 7: gradingScale = gradingScaleTest8; break;
            default: throw new IllegalArgumentException("Invalid test index");
        }
        return interpolate(testScores.get(testIndex), gradingScale);
    }
    public double calculateCategoryScore(int index1, int index2) {
        return scoreTest(index1) + scoreTest(index2);
    }

    public String determineBestCategory() {
        double strength = calculateCategoryScore(0, 4);
        double endurance = calculateCategoryScore(1, 3);
        double balance = calculateCategoryScore(2, 5);
        double agility = calculateCategoryScore(6, 7);
        
        if (strength >= endurance && strength >= balance && strength >= agility) return "Muscular Strength";
        if (endurance >= strength && endurance >= balance && endurance >= agility) return "Muscular Endurance";
        if (balance >= strength && balance >= endurance && balance >= agility) return "Balance";
        return "Speed and Agility";
    }
    public int calculateAge() {
        if (birthDate == null) {
            throw new IllegalStateException("Birthdate is not set.");
        }
        return Period.between(birthDate, LocalDate.now()).getYears();
    }

    public double calculateBMI() {
        return weight / Math.pow(height / 100.0, 2);
    }

    public boolean hasHealthIssues() {
        double bmi = calculateBMI();
        return bmi > 30 || bmi < 15;
    }

    public boolean isEligibleAge() {
        int age = calculateAge();
        return age >= 6 && age <= 9;
    }

    public List<String> getPreferredSports() {
        return (preferredSports != null) ? preferredSports : Collections.emptyList();
    }

    public List<String> getParentSportsHistory() {
        return (parentSportsHistory != null) ? parentSportsHistory : Collections.emptyList();
    }
    
    public void setPreferredSports(List<String> preferredSports) {
        this.preferredSports = preferredSports;
    }

    public void setParentSportsHistory(List<String> parentSportsHistory) {
        this.parentSportsHistory = parentSportsHistory;
    }

     
    public void setTestScores(List<Double> testScores) {
        this.testScores = testScores;
    }


    public boolean isMedicallyCleared() {
    	System.out.println("🔹 Checking medical clearance...");
        System.out.println("   - hasDoctorApproval: " + hasDoctorApproval);
        System.out.println("   - hasNormalBloodTest: " + hasNormalBloodTest);
    	return hasDoctorApproval && hasNormalBloodTest;
    }

    public String getBestCategory() {
        return bestCategory;
    }
    public Map<String, Double> getCategoryScores() { return categoryScores; }
    public void setCategoryScores(Map<String, Double> categoryScores) { this.categoryScores = categoryScores; }

    public Map<String, Double> getCategoryPercentages() { return categoryPercentages; }
    public void setCategoryPercentages(Map<String, Double> categoryPercentages) { this.categoryPercentages = categoryPercentages; }

    public void setBestCategory(String category) {
        this.bestCategory = category;
    }

	public String getName() {
		// TODO Auto-generated method stub
		return this.name;
	}
	public List<Double> getTestScores() {  // Ensure this getter exists
        return testScores;
    }
	public void setSchoolType(String schoolType) {
	    this.schoolType = schoolType;
	}

	public void setGender(String gender) {
	    this.gender = gender;
	}

	public void setHeight(double height) {
	    this.height = height;
	}

	public void setWeight(double weight) {
	    this.weight = weight;
	}
	 
	//for handling errors from data 
	private List<String> errors = new ArrayList<>();

	public void addError(String error) {
	    this.errors.add(error);
	}

	public List<String> getErrors() {
	    return errors;
	}
	
	 

    // Method to fetch the test results
     
    // Method to set the test results
    public void setDetailedTestResults(List<TestResult> detailedTestResults) {
        this.detailedTestResults = detailedTestResults;
    }
	 
/**********************************************/

	@Data
    public static class TestResult {
        private String testNameEn;
        private String testNameAr;
        private double testValue;
        private String gradeLevel;
        public String getTestNameEn() { return testNameEn; }
        public void setTestNameEn(String testNameEn) { this.testNameEn = testNameEn; }

        public String getTestNameAr() { return testNameAr; }
        public void setTestNameAr(String testNameAr) { this.testNameAr = testNameAr; }

        public double getTestValue() { return testValue; }
        public void setTestValue(double testValue) { this.testValue = testValue; }

        public String getGradeLevel() { return gradeLevel; }
        public void setGradeLevel(String gradeLevel) { this.gradeLevel = gradeLevel; }

		 
	}
	private List<TestResult> detailedTestResults = new ArrayList<>();

	private String gradeLevel;

	private double testValue;

	private String testNameAr;

	private String testNameEn;
	
	public static String determineGradeLevel(double value, TreeMap<Integer, Double> gradingScale) {
	    double p25 = gradingScale.floorEntry(25).getValue();
	    double p50 = gradingScale.floorEntry(50).getValue();
	    double p75 = gradingScale.floorEntry(75).getValue();

	    if (value < p25) return "Weak";
	    else if (value < p50) return "Average";
	    else if (value < p75) return "Above Average";
	    else return "Excellent";
	}
	
	public List<TestResult> getDetailedTestResults() {
	    return detailedTestResults;
	}
	// Detailed test results (setter/getter could be Lombok-generated or manually written)
 

    // Getters for grading scales
    public static TreeMap<Integer, Double> getGradingScaleTest1() {
        return gradingScaleTest1;
    }
    
    public static TreeMap<Integer, Double> getGradingScaleTest2() {
        return gradingScaleTest2;
    }
    
    public static TreeMap<Integer, Double> getGradingScaleTest3() {
        return gradingScaleTest3;
    }
    
    public static TreeMap<Integer, Double> getGradingScaleTest4() {
        return gradingScaleTest4;
    }
    
    public static TreeMap<Integer, Double> getGradingScaleTest5() {
        return gradingScaleTest5;
    }
    
    public static TreeMap<Integer, Double> getGradingScaleTest6() {
        return gradingScaleTest6;
    }
    
    public static TreeMap<Integer, Double> getGradingScaleTest7() {
        return gradingScaleTest7;
    }
    
    public static TreeMap<Integer, Double> getGradingScaleTest8() {
        return gradingScaleTest8;
    }
    // Getter and Setter for testNameEn (English name)
    public String getTestNameEn() {
        return testNameEn;
    }

    public void setTestNameEn(String testNameEn) {
        this.testNameEn = testNameEn;
    }

    // Getter and Setter for testNameAr (Arabic name)
    public String getTestNameAr() {
        return testNameAr;
    }

    public void setTestNameAr(String testNameAr) {
        this.testNameAr = testNameAr;
    }

    // Getter and Setter for testValue (test score)
    public double getTestValue() {
        return testValue;
    }

    public void setTestValue(double testValue) {
        this.testValue = testValue;
    }

    // Getter and Setter for gradeLevel (grade level)
    public String getGradeLevel() {
        return gradeLevel;
    }

    public void setGradeLevel(String gradeLevel) {
        this.gradeLevel = gradeLevel;
    }
}
	





