package com.example.drools.service;

import com.example.drools.model.Player;
import org.kie.api.runtime.KieSession;
import org.springframework.stereotype.Service;

@Service
public class DroolsService {

    private final KieSession kieSession;

    public DroolsService(KieSession kieSession) {
        this.kieSession = kieSession;
    }

    public Player evaluatePlayer(Player player) {
        kieSession.insert(player);
        kieSession.fireAllRules();
        return player;  // Player object now contains the best category & category scores
    }
}
